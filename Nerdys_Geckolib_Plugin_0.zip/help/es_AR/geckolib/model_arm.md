Este será el nombre utilizado cuando se busque un grupo de modelos para desactivarlo y sustituirlo por un brazo de jugador.
Ese brazo tendrá las animaciones que tenga el grupo de modelos.
Si el grupo de modelos especificado no existe, el brazo no se renderizará.
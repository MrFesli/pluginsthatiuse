GeckoLib中json模型和动画的名称。
